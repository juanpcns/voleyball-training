import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:voleyballtraining/Views/Styles/templates/container_default.dart';
import 'package:voleyballtraining/Views/Styles/templates/home_view_template.dart';
import 'package:voleyballtraining/views/perfil/perfil_view.dart';
import 'package:voleyballtraining/views/plans/training_plans_view.dart';
import 'package:voleyballtraining/views/progreso/progreso_view.dart';
import 'package:voleyballtraining/views/usuarios/ver_perfiles_view.dart';
import 'package:voleyballtraining/views/login_view.dart';
import 'package:voleyballtraining/providers/auth_provider.dart';

class MainMenuView extends StatelessWidget {
  const MainMenuView({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final String? nombre = authProvider.userName;
    final String? rol = authProvider.userRole;
    final bool esEntrenador = rol?.toLowerCase() == 'entrenador';

    Widget content = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const CircleAvatar(
          backgroundColor: Color(0xFFFF9F1C),
          radius: 30,
          child: Text("🏐", style: TextStyle(fontSize: 28)),
        ),
        const SizedBox(height: 10),
        Text("Bienvenido, ${nombre ?? ''}",
            style: const TextStyle(color: Color(0xFFFF9F1C), fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text("Explora las opciones de tu cuenta", style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),

        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _buildPanelItem(context, "Perfil", "assets/icons/user.png", const PerfilView()),
            _buildPanelItem(context, "Planes", "assets/icons/plan.png", const TrainingPlansView()),
            _buildPanelItem(context, "Chats", "assets/icons/chat.png", const ChatsView()),
            _buildPanelItem(context, "Estadísticas", "assets/icons/chart.png", const ProgresoView()),
            if (esEntrenador)
              _buildPanelItem(context, "Perfiles", "assets/icons/group.png", const VerPerfilesView()),
          ],
        ),
        const SizedBox(height: 20),

        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF8B0000),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
          ),
          onPressed: () {
            authProvider.logout();

            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const LoginView()),
              (_) => false,
            );
          },
          child: const Text("Cerrar Sesión", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        )
      ],
    );

    return HomeViewTemplate(
      title: '',
      body: ContainerDefault(child: content),
    );
  }

  Widget _buildPanelItem(BuildContext context, String label, String iconPath, Widget destinationView) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => destinationView));
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(iconPath, width: 28, height: 28),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(color: Colors.white, fontSize: 14)),
          ],
        ),
      ),
    );
  }
}
